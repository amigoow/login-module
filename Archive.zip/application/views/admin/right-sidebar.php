<div class="col-lg-3 ds">
  
  <h3>NOTIFICATIONS</h3>
                      
  
  <div class="desc">
  	<div class="thumb">
  		<span class="badge bg-theme"><i class="fa fa-clock-o"></i></span>
  	</div>
  	<div class="details">
  		<p><muted>2 Minutes Ago</muted><br/>
  		   <a href="#">James Brown</a> subscribed to your newsletter.<br/>
  		</p>
  	</div>
  </div>
</div><!-- /col-lg-3 -->