<section id="container" >
      <!-- **********************************************************************************************************************************************************
      TOP BAR CONTENT & NOTIFICATIONS
      *********************************************************************************************************************************************************** -->
      <!--header start-->
      <?php $this->view('admin/sub-header.php'); ?>
      <!--header end-->
      
      <!-- **********************************************************************************************************************************************************
      MAIN SIDEBAR MENU
      *********************************************************************************************************************************************************** -->
      <!--sidebar start-->
      <?php $this->view('admin/left-sidebar.php') ?>
      <!--sidebar end-->
      
      <!-- **********************************************************************************************************************************************************
      MAIN CONTENT
      *********************************************************************************************************************************************************** -->
      <!--main content start-->
      <section id="main-content">
          <section class="wrapper">
          	<h3><i class="fa fa-angle-right"></i> Review Ratings - <small> the insights</small></h3>
            
          	<!-- BASIC FORM ELELEMNTS -->
          	<div class="row mt">
          		<div class="col-lg-12" id="social_accounts_scraped">
                  <br/>
                  <h4>Click on following buttons to see details</h4>
                  <ul class="nav nav-tabs" id="social_accounts_tabs">
                    
                  </ul>

                  <div class="tab-content" id="social_accounts_tabs_content">
                    <!-- main info -->
                    <div class=" main_info">
                      
                      

                    </div>  <!-- main info -->

                    <div class=" individual_ratings">
                     

                    </div>
                    <hr>
                    
                  </div>

                  
                  
                  <hr>
                  
          		</div><!-- col-lg-12-->      	
          	</div><!-- /row -->
          </section>
      </section><!-- /MAIN CONTENT -->
      
