<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<div class="container">
	<div class="row">
		<div class="col-md-12">
			<div class="page-header">
				<h1><i class="fa fa-envelope fa-3x"></i> Email not confirmed :( </h1>
			</div>
			<p>Login details are correct but you need to confirm your email(<?php echo $email; ?>) to proceed!</p>
		</div>
	</div><!-- .row -->
</div><!-- .container -->