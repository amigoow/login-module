<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
	
	</main><!-- #site-content -->
	
	<img src="<?php echo base_url('assets/imgs/loading.gif'); ?>" id="ajax-load" style="display:none" />
    
    <footer>© <?php echo date("Y"); ?> Reviewthefirm.com All Rights Reserved</footer><!-- #site-footer -->

    

	<!-- bootstrap -->
	<script src="<?= base_url('assets/js/bootstrap.min.js') ?>"></script>

	<!-- noty -->
	<script src="<?= base_url('assets/node_modules/noty/packaged/jquery.noty.packaged.min.js') ?>"></script>
	<!-- bootbox -->
	<script src="<?= base_url('assets/node_modules/bootbox/bootbox.min.js') ?>"></script>

	<!-- star rating -->
	<script src="<?php echo base_url('assets/js/star-rating.min.js'); ?>" type="text/javascript"></script>

	<!-- custom js -->
	<script src="<?= base_url('assets/js/script.js') ?>"></script>


</body>
</html>